<?php
/**
 * Load 3rd party compatibility tweaks.
 */
require_once( JOB_MANAGER_PLUGIN_DIR . '/includes/3rd-party/jetpack.php' );
require_once( JOB_MANAGER_PLUGIN_DIR . '/includes/3rd-party/wpml.php' );
require_once( JOB_MANAGER_PLUGIN_DIR . '/includes/3rd-party/polylang.php' );
require_once( JOB_MANAGER_PLUGIN_DIR . '/includes/3rd-party/yoast.php' );
require_once( JOB_MANAGER_PLUGIN_DIR . '/includes/3rd-party/all_in_one_seo_pack.php' );
