<?php
/**
 * Serp Preview
 *
 * @package    RankMath
 * @subpackage RankMath\Metaboxes
 */

$checklist = new RankMath\Admin\Serp_Preview;
$checklist->display();
