<?php
/**
 * Display SERP checklist
 *
 * @package    RankMath
 * @subpackage RankMath\Metaboxes
 */

$checklist = new RankMath\Admin\Serp_Checklist;
$checklist->display();
