<?php
/**
 * This class registers all the necessary styles and scripts.
 *
 * @since      0.9.0
 * @package    RankMath
 * @subpackage RankMath\Admin
 * @author     MyThemeShop <admin@mythemeshop.com>
 */

namespace RankMath\Admin;

use RankMath\Traits\Hooker;
use RankMath\Helper as GlobalHelper;

defined( 'ABSPATH' ) || exit;

/**
 * Assets class.
 *
 * @codeCoverageIgnore
 */
class Assets {

	use Hooker;

	/**
	 *  Prefix for naming the assets.
	 */
	const PREFIX = 'rank-math-';

	/**
	 * The Constructor.
	 */
	public function __construct() {
		$this->action( 'admin_enqueue_scripts', 'register' );
		$this->action( 'admin_enqueue_scripts', 'enqueue', 25 );
		$this->action( 'admin_enqueue_scripts', 'overwrite_wplink', 99 );
	}

	/**
	 * Register styles and scripts required by plugin.
	 */
	public function register() {

		$js     = rank_math()->plugin_url() . 'assets/admin/js/';
		$css    = rank_math()->plugin_url() . 'assets/admin/css/';
		$vendor = rank_math()->plugin_url() . 'assets/vendor/';

		// Styles.
		wp_register_style( self::PREFIX . 'common', $css . 'common.css', null, rank_math()->get_version() );
		wp_register_style( self::PREFIX . 'cmb2', $css . 'cmb2.css', null, rank_math()->get_version() );
		wp_register_style( self::PREFIX . 'dashboard', $css . 'dashboard.css', array( 'rank-math-common' ), rank_math()->get_version() );
		wp_register_style( self::PREFIX . 'plugin-feedback', $css . 'feedback.css', array( 'rank-math-common' ), rank_math()->get_version() );

		// Scripts.
		wp_register_script( 'clipboard', rank_math()->plugin_url() . 'assets/vendor/clipboard.min.js', null, '2.0.0', true );
		wp_register_script( self::PREFIX . 'common', $js . 'common.js', array( 'jquery' ), rank_math()->get_version(), true );
		wp_register_script( self::PREFIX . 'dashboard', $js . 'dashboard.js', array( 'jquery', 'clipboard' ), rank_math()->get_version(), true );
		wp_register_script( self::PREFIX . 'plugin-feedback', $js . 'feedback.js', array( 'jquery' ), rank_math()->get_version(), true );

		// Select2.
		wp_register_style( 'select2-rm', $vendor . 'select2/select2.min.css', null, '4.0.6-rc.1' );
		wp_register_script( 'select2-rm', $vendor . 'select2/select2.min.js', null, '4.0.6-rc.1', true );

		rank_math()->add_json( 'hasPremium', \class_exists( '\\RankMath\\Premium' ) );

		/**
		 * Allow other plugins to register styles or scripts into admin after plugin assets.
		 */
		$this->do_action( 'admin/register_scripts' );
	}

	/**
	 * Enqueue Styles and Scripts required by plugin.
	 */
	public function enqueue() {
		$screen = get_current_screen();

		// Our screens only.
		if ( ! in_array( $screen->taxonomy, GlobalHelper::get_allowed_taxonomies() ) && ! in_array( $screen->id, $this->get_admin_screen_ids() ) ) {
			return;
		}

		// Add thank you.
		$this->filter( 'admin_footer_text', 'admin_footer_text' );

		rank_math()->add_json( 'maxTags', GlobalHelper::is_mythemeshop_connected() ? 5 : 1 );

		/**
		 * Allow other plugins to enqueue styles or scripts into admin after plugin assets.
		 */
		$this->do_action( 'admin/enqueue_scripts' );
	}

	/**
	 * Add footer credit on admin pages.
	 *
	 * @param string $text Default text for admin footer.
	 * @return string
	 */
	public function admin_footer_text( $text ) {
		/* translators: plugin url */
		return GlobalHelper::is_whitelabel() ? $text : '<em>' . sprintf( wp_kses_post( __( 'Thank you for using <a href="%s" target="_blank">Rank Math</a>', 'rank-math' ) ), 'https://mythemeshop.com/plugins/wordpress-seo/' ) . '</em>';
	}

	/**
	 * Overwrite wplink script file.
	 */
	public function overwrite_wplink() {

		wp_deregister_script( 'wplink' );
		wp_register_script( 'wplink', rank_math()->plugin_url() . 'assets/admin/js/wplink.js', array( 'jquery', 'wpdialogs' ), null, true );

		wp_localize_script( 'wplink', 'wpLinkL10n', array(
			'title'          => esc_html__( 'Insert/edit link', 'rank-math' ),
			'update'         => esc_html__( 'Update', 'rank-math' ),
			'save'           => esc_html__( 'Add Link', 'rank-math' ),
			'noTitle'        => esc_html__( '(no title)', 'rank-math' ),
			'noMatchesFound' => esc_html__( 'No matches found.', 'rank-math' ),
			'linkSelected'   => esc_html__( 'Link selected.', 'rank-math' ),
			'linkInserted'   => esc_html__( 'Link inserted.', 'rank-math' ),
			'relCheckbox'    => __( 'Add <code>rel="nofollow"</code>', 'rank-math' ),
			'linkTitle'      => esc_html__( 'Link Title', 'rank-math' ),
		) );
	}

	/**
	 * Enqueues styles.
	 *
	 * @param string $style The name of the style to enqueue.
	 */
	public function enqueue_style( $style ) {
		wp_enqueue_style( self::PREFIX . $style );
	}

	/**
	 * Enqueues scripts.
	 *
	 * @param string $script The name of the script to enqueue.
	 */
	public function enqueue_script( $script ) {
		wp_enqueue_script( self::PREFIX . $script );
	}

	/**
	 * Get admin screen ids.
	 *
	 * @return array
	 */
	private function get_admin_screen_ids() {
		$pages = array(
			'toplevel_page_rank-math',
			'rank-math_page_rank-math-role-manager',
			'rank-math_page_rank-math-seo-analysis',
			'rank-math_page_rank-math-404-monitor',
			'rank-math_page_rank-math-redirections',
			'rank-math_page_rank-math-link-builder',
			'rank-math_page_rank-math-search-console',
			'rank-math_page_rank-math-import-export',
			'rank-math_page_rank-math-help',
			'user-edit',
			'profile',
		);

		return array_merge( $pages, GlobalHelper::get_allowed_post_types() );
	}
}
