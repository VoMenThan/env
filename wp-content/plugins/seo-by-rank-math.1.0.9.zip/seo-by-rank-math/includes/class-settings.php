<?php
/**
 * The settings functionality of the plugin.
 *
 * @since      0.9.0
 * @package    RankMath
 * @subpackage RankMath\Core
 * @author     MyThemeShop <admin@mythemeshop.com>
 */

namespace RankMath;

use RankMath\Traits\Hooker;
use RankMath\Admin\Options;
use RankMath\Admin\Helper as Admin_Helper;

defined( 'ABSPATH' ) || exit;

/**
 * Settings class.
 */
class Settings {

	use Hooker;

	/**
	 * Hold option data.
	 *
	 * @var array
	 */
	private $keys = array();

	/**
	 * Options holder.
	 *
	 * @var array
	 */
	private $options = null;

	/**
	 * The Constructor.
	 */
	public function __construct() {

		// Add fields.
		if ( is_admin() ) {
			$this->action( 'init', 'general_settings' );
			$this->action( 'init', 'title_settings', 999 );
			$this->filter( 'rank_math/settings/title', 'title_post_type_settings' );
			$this->filter( 'rank_math/settings/title', 'title_taxonomy_settings' );
		}

		// Add options data to stream.
		$this->add_options( 'titles', 'rank-math-options-titles' );
		$this->add_options( 'general', 'rank-math-options-general' );
		$this->add_options( 'sitemap', 'rank-math-options-sitemap' );

		// Check for fields and act accordingly.
		$this->action( 'cmb2_save_options-page_fields_rank-math-options-general_options', 'check_updated_fields', 25, 2 );
		$this->action( 'cmb2_save_options-page_fields_rank-math-options-titles_options', 'check_updated_fields', 25, 2 );
	}

	/**
	 * Register SEO Titles & Meta Settings.
	 */
	public function title_settings() {
		$tabs = array(
			'global'   => array(
				'icon'  => 'fa fa-cogs',
				'title' => esc_html__( 'Global Meta', 'rank-math' ),
				/* translators: Link to KB article */
				'desc'  => sprintf( esc_html__( 'This tab contains SEO titles and meta options related to all the pages of your site. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
			'local'    => array(
				'icon'  => 'fa fa-map-marker',
				'title' => esc_html__( 'Local SEO', 'rank-math' ),
				/* translators: Redirection page url */
				'desc'  => sprintf( wp_kses_post( __( 'This tab contains settings related to contact information & opening hours of your local business. Use the <code>[rank_math_contact_info]</code> shortcode to display contact information in a nicely formatted way. %s. You should also claim your business on Google if you have not already.', 'rank-math' ) ), '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#local-seo" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
			'social'   => array(
				'icon'  => 'fa fa-retweet',
				'title' => esc_html__( 'Social Meta', 'rank-math' ),
				/* translators: Link to social setting KB article */
				'desc'  => sprintf( esc_html__( 'This tab contains settings related to social networks and feeds. Social page URLs will be displayed in the contact shortcode and added to the pages as metadata to be displayed in Knowledge Graph cards. Unable to find the details? %s for the tutorial.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#social-meta" target="_blank">' . esc_html__( 'Click here', 'rank-math' ) . '</a>' ),
			),
			'homepage' => array(
				'icon'  => 'fa fa-home',
				'title' => esc_html__( 'Homepage', 'rank-math' ),
				'desc'  => 'page' == get_option( 'show_on_front' ) ?
					/* translators: something */
					sprintf( wp_kses_post( __( 'A static page is used as front page (as set in Settings &gt; Reading). To set up the title, description, and meta of the homepage, use the meta box in the page editor.<br><br><a href="%1$s">Edit Page: %2$s</a>', 'rank-math' ) ), admin_url( 'post.php?post=' . get_option( 'page_on_front' ) ) . '&action=edit', get_the_title( get_option( 'page_on_front' ) ) ) :
					/* translators: Link to KB article */
					sprintf( esc_html__( 'This tab contains SEO options for your website\'s homepage. Change options like homepage title and homepage meta description here. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#homepage" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
			'author'   => array(
				'icon'  => 'fa fa-users',
				'title' => esc_html__( 'Authors', 'rank-math' ),
				/* translators: Link to KB article */
				'desc'  => sprintf( esc_html__( 'Change SEO options related to the author archive pages. Author archives list the posts from a particular author in chronological order. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#authors" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
			'misc'     => array(
				'icon'  => 'fa fa-map-signs',
				'title' => esc_html__( 'Misc Pages', 'rank-math' ),
				/* translators: Link to KB article */
				'desc'  => sprintf( esc_html__( 'This tab contains meta data settings related to pages like search results, 404 error pages etc. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#misc-pages" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
		);

		/**
		 * Allow developers to add new section into title setting option panel.
		 *
		 * @param array $tabs
		 */
		$tabs = $this->do_filter( 'settings/title', $tabs );

		new Options( array(
			'key'        => 'rank-math-options-titles',
			'title'      => esc_html__( 'SEO Titles &amp; Meta', 'rank-math' ),
			'menu_title' => esc_html__( 'Titles &amp; Meta', 'rank-math' ),
			'capability' => 'rank_math_titles',
			'folder'     => 'titles',
			'tabs'       => $tabs,
		));

		if ( is_admin() ) {
			rank_math()->add_json( 'postTitle', 'Post Title' );
			rank_math()->add_json( 'postUri', home_url( '/post-title' ) );
			rank_math()->add_json( 'blogName', get_bloginfo( 'name' ) );
		}
	}

	/**
	 * Add post type tabs into title option panel
	 *
	 * @param  array $tabs Hold tabs for optional panel.
	 * @return array
	 */
	public function title_post_type_settings( $tabs ) {
		$icons = Helper::choices_post_type_icons();
		$links = array(
			'post'       => '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#Posts" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>.',
			'page'       => '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#pages" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>.',
			'product'    => '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#products" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>.',
			'attachment' => '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#media" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>.',
		);

		$names = array(
			'post'       => 'single %s',
			'page'       => 'single %s',
			'product'    => 'product pages',
			'attachment' => 'media %s',
		);

		$tabs['p_types'] = array(
			'title' => esc_html__( 'Post Types:', 'rank-math' ),
			'type'  => 'seprator',
		);
		foreach ( Helper::get_accessible_post_types() as $post_type ) {
			$obj      = get_post_type_object( $post_type );
			$link     = isset( $links[ $obj->name ] ) ? $links[ $obj->name ] : '';
			$obj_name = isset( $names[ $obj->name ] ) ? sprintf( $names[ $obj->name ], $obj->name ) : $obj->name;

			$tabs[ 'post-type-' . $obj->name ] = array(
				'title'     => $obj->label,
				'icon'      => isset( $icons[ $obj->name ] ) ? $icons[ $obj->name ] : $icons['default'],
				/* translators: 1. post type name 2. link */
				'desc'      => sprintf( esc_html__( 'This tab contains SEO options for %1$s. %2$s', 'rank-math' ), $obj_name, $link ),
				'post_type' => $obj->name,
				'file'      => rank_math()->includes_dir() . 'settings/titles/post-types.php',
			);
		}

		return $tabs;
	}

	/**
	 * Add taxonomy tabs into title option panel
	 *
	 * @param  array $tabs Hold tabs for optional panel.
	 * @return array
	 */
	public function title_taxonomy_settings( $tabs ) {
		$icons = Helper::choices_taxonomy_icons();

		$hash_name = array(
			'category'    => 'category archive pages',
			'product_cat' => 'Product category pages',
			'product_tag' => 'Product tag pages',
		);

		$hash_link = array(
			'category'    => '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#categories" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>.',
			'product_cat' => '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#product-categories" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>.',
			'product_tag' => '<a href="https://mythemeshop.com/kb/wordpress-seo-plugin-rank-math/titles-and-meta/#product-tags" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>.',
		);

		foreach ( Helper::get_accessible_taxonomies() as $taxonomy ) {
			$attached = implode( ' + ', $taxonomy->object_type );

			// Seprator.
			$tabs[ $attached ] = array(
				'title' => ucwords( $attached ) . ':',
				'type'  => 'seprator',
			);

			$link          = isset( $hash_link[ $taxonomy->name ] ) ? $hash_link[ $taxonomy->name ] : '';
			$taxonomy_name = isset( $hash_name[ $taxonomy->name ] ) ? $hash_name[ $taxonomy->name ] : $taxonomy->label;

			$tabs[ 'taxonomy-' . $taxonomy->name ] = array(
				'icon'     => isset( $icons[ $taxonomy->name ] ) ? $icons[ $taxonomy->name ] : $icons['default'],
				'title'    => $taxonomy->label,
				/* translators: 1. taxonomy name 2. link */
				'desc'     => sprintf( esc_html__( 'This tab contains SEO options for %1$s. %2$s', 'rank-math' ), $taxonomy_name, $link ),
				'taxonomy' => $taxonomy->name,
				'file'     => rank_math()->includes_dir() . 'settings/titles/taxonomies.php',
			);
		}

		if ( isset( $tabs['taxonomy-post_format'] ) ) {
			$tab = $tabs['taxonomy-post_format'];
			unset( $tabs['taxonomy-post_format'] );
			$tab['title']      = esc_html__( 'Post Formats', 'rank-math' );
			$tab['page_title'] = esc_html__( 'Post Formats Archive', 'rank-math' );
			Helper::array_insert( $tabs, array( 'taxonomy-post_format' => $tab ), 5 );
		}

		return $tabs;
	}

	/**
	 * General Settings.
	 */
	public function general_settings() {

		/**
		 * Allow developers to add new section into general setting option panel.
		 *
		 * @param array $tabs
		 */
		$tabs = $this->do_filter( 'settings/general', array(
			'links'       => array(
				'icon'  => 'fa fa-link',
				'title' => esc_html__( 'Links', 'rank-math' ),
				/* translators: Link to kb article */
				'desc'  => sprintf( esc_html__( 'This tab contains the options related to links and URLs. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/rank-math-seo-plugin/general-settings/#links" target="_blank">' . esc_html__( 'Learn More', 'rank-math' ) . '</a>' ),
			),
			'images'      => array(
				'icon'  => 'dashicons dashicons-images-alt2',
				'title' => esc_html__( 'Images', 'rank-math' ),
				/* translators: Link to kb article */
				'desc'  => sprintf( esc_html__( 'SEO options related to featured images and media appearing in your post content. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/rank-math-seo-plugin/general-settings/#images" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
			'breadcrumbs' => array(
				'icon'  => 'fa fa-angle-double-right',
				'title' => esc_html__( 'Breadcrumbs', 'rank-math' ),
				/* translators: Link to kb article */
				'desc'  => sprintf( esc_html__( 'Here you can set up the breadcrumbs function. %s Use the following code in your theme template files to display breadcrumbs:', 'rank-math' ), '<a href="https://mythemeshop.com/kb/rank-math-seo-plugin/general-settings/#breadcrumbs" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>. <br/>' ) . '<br /><code>&lt;?php if (function_exists(\'rank_math_the_breadcrumbs\')) rank_math_the_breadcrumbs(); ?&gt;</code><br /> OR <br /><code>[rank_math_breadcrumb]</code>',
			),
			'webmaster'   => array(
				'icon'  => 'fa fa-external-link',
				'title' => esc_html__( 'Webmaster Tools', 'rank-math' ),
				/* translators: Link to kb article */
				'desc'  => sprintf( esc_html__( 'Here you can enter verification codes for various third-party webmaster tools. %s You can safely paste the full HTML tags, or just the ID codes.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/rank-math-seo-plugin/general-settings/#webmaster-tools" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>.<br />' ),
			),
			'robots'      => array(
				'icon'  => 'fa fa-simplybuilt',
				'title' => esc_html__( 'Edit robots.txt', 'rank-math' ),
				/* translators: Link to kb article */
				'desc'  => sprintf( esc_html__( 'Here you can edit the virtual robots.txt file. Leave the field empty to let WordPress handle the contents dynamically. If an actual robots.txt file is present in the root folder of your site, this option won\'t take effect and you have to edit the file directly, or delete it and then edit from here. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/rank-math-seo-plugin/general-settings/#edit-robotstxt" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
			'htaccess'    => array(
				'icon'  => 'fa fa-file',
				'title' => esc_html__( 'Edit .htaccess', 'rank-math' ),
				/* translators: Link to kb article */
				'desc'  => sprintf( esc_html__( 'Here you can edit the contents of your .htaccess file. This file is mainly used by WordPress to control permalinks and redirections, but it may be useful to edit it in a number of cases. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/rank-math-seo-plugin/general-settings/#edit-htaccess" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
			'others'      => array(
				'icon'  => 'fa fa-dot-circle-o',
				'title' => esc_html__( 'Others', 'rank-math' ),
				/* translators: Link to kb article */
				'desc'  => sprintf( esc_html__( 'Control how your plugin communicates with MyThemeShop and change how your RSS content looks. %s.', 'rank-math' ), '<a href="https://mythemeshop.com/kb/rank-math-seo-plugin/general-settings/#others" target="_blank">' . esc_html__( 'Learn more', 'rank-math' ) . '</a>' ),
			),
		) );

		if ( is_multisite() ) {
			unset( $tabs['robots'] );
		}

		if ( ! Helper::has_cap( 'edit_htaccess' ) && is_multisite() ) {
			unset( $tabs['htaccess'] );
		}

		new Options( array(
			'key'        => 'rank-math-options-general',
			'title'      => esc_html__( 'SEO Settings', 'rank-math' ),
			'menu_title' => esc_html__( 'General Settings', 'rank-math' ),
			'capability' => 'rank_math_general',
			'folder'     => 'general',
			'tabs'       => $tabs,
		));
	}

	/**
	 * Check if certain fields got updated.
	 *
	 * @param int   $object_id The ID of the current object.
	 * @param array $updated   Array of field ids that were updated.
	 *                         Will only include field ids that had values change.
	 */
	public function check_updated_fields( $object_id, $updated ) {

		/**
		 * Allow developers to add option fields to check against updatation.
		 * And if updated flush the rewrite rules.
		 *
		 * @param array $flush_fields Array of fields id for which we need to flush.
		 */
		$flush_fields = $this->do_filter( 'flush_fields', array( 'strip_category_base', 'disable_author_archives', 'url_author_base', 'attachment_redirect_urls', 'attachment_redirect_default', 'url_strip_stopwords', 'nofollow_external_links', 'nofollow_image_links', 'nofollow_domains', 'nofollow_exclude_domains', 'new_window_external_links', 'redirections_header_code', 'redirections_post_redirect', 'redirections_debug' ) );

		foreach ( $flush_fields as $field_id ) {
			if ( in_array( $field_id, $updated ) ) {
				Helper::schedule_flush_rewrite();
				break;
			}
		}

		// Update .htaccess.
		if ( isset( $_POST['htaccess_accept_changes'] ) && isset( $_POST['htaccess_content'] ) ) {

			$content = stripslashes( $_POST['htaccess_content'] );

			if ( ! Admin_Helper::do_htaccess_backup() ) {
				rank_math()->add_deferred_error( esc_html__( 'Failed to backup .htaccess file. Please check file permissions.', 'rank-math' ) );
				return;
			}
			if ( ! Admin_Helper::do_htaccess_update( $content ) ) {
				rank_math()->add_deferred_error( esc_html__( 'Failed to update .htaccess file. Please check file permissions.', 'rank-math' ) );
				return;
			}
			rank_math()->add_deferred_error( esc_html__( '.htaccess file updated successfully.', 'rank-math' ), 'success' );
		}
	}

	/**
	 * Get settings keys.
	 *
	 * @return array
	 */
	public function get_keys() {
		return $this->keys;
	}

	/**
	 * Get Setting.
	 *
	 * @param  string $field_id ID of field to get.
	 * @param  mixed  $default  (Optional) Default value.
	 * @return mixed
	 */
	public function get( $field_id = '', $default = false ) {
		$opts = $this->get_options();
		$ids  = explode( '.', $field_id );

		foreach ( $ids as $id ) {
			if ( is_null( $opts ) ) {
				break;
			}
			$opts = isset( $opts[ $id ] ) ? $opts[ $id ] : null;
		}

		if ( is_null( $opts ) ) {
			return $default;
		}

		return $opts;
	}

	/**
	 * Set value.
	 *
	 * @param string $group Setting group.
	 * @param string $id    Setting id.
	 * @param string $value Setting value.
	 */
	public function set( $group, $id, $value ) {
		$this->options[ $group ][ $id ] = $value;
	}

	/**
	 * Get all settings.
	 *
	 * @return array
	 */
	public function all() {
		return $this->get_options();
	}

	/**
	 * Get all settings.
	 *
	 * @return array
	 */
	public function all_raw() {
		$options = array();
		if ( ! empty( $this->keys ) ) {
			foreach ( $this->keys as $id => $key ) {
				$options[ $id ] = get_option( $key, array() );
			}
		}

		return $options;
	}

	/**
	 * Get options once for use throughout the plugin cycle.
	 *
	 * @return array
	 */
	public function get_options() {

		if ( is_null( $this->options ) && ! empty( $this->keys ) ) {

			$options = array();
			foreach ( $this->keys as $id => $key ) {
				$options[ $id ] = get_option( $key, array() );
			}

			$this->options = $this->normalize_it( $options );
		}

		return (array) $this->options;
	}

	/**
	 * Add new option data.
	 *
	 * @param string $id  Unique id.
	 * @param string $key Option key.
	 */
	public function add_options( $id, $key ) {

		if ( ! empty( $id ) && ! empty( $key ) ) {

			$this->keys[ $id ] = $key;

			// Lazy-Load options.
			if ( ! is_null( $this->options ) ) {
				$options = get_option( $key, array() );
				$options = $this->normalize_it( $options );

				$this->options[ $id ] = $options;
			}
		}
	}

	/**
	 * Normalize option data
	 *
	 * @param mixed $options Array to normalize.
	 * @return mixed
	 */
	private function normalize_it( $options ) {
		foreach ( (array) $options as $key => $value ) {
			$options[ $key ] = is_array( $value ) ? $this->normalize_it( $value ) : Helper::normalize_data( $value );
		}

		return $options;
	}
}
