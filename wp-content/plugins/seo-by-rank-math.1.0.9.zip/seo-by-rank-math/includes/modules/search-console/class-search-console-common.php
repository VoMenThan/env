<?php
/**
 * Methods for frontend and backend in admin-only module
 *
 * @since      0.9.0
 * @package    RANK_MATH
 * @subpackage RANK_MATH/modules
 * @author     MyThemeShop <admin@mythemeshop.com>
 */

namespace RankMath\Modules\Search_Console;

use RankMath\Helper;
use RankMath\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Search_Console class.
 */
class Search_Console_Common extends Module {

	/**
	 * The Constructor
	 */
	public function __construct() {

		if ( Helper::is_heartbeat() ) {
			return;
		}

		if ( Helper::has_cap( 'search_console' ) ) {
			$this->filter( 'rank_math/admin_bar/items', 'admin_bar_items', 11 );
		}
		$this->action( 'rank_math/search_console/get_analytics', 'add_day_crawler' );
	}

	/**
	 * Add admin bar item.
	 *
	 * @param array $items Array of admin bar nodes.
	 * @return array
	 */
	public function admin_bar_items( $items ) {
		// Add link only if connected?
		$items['search-console'] = array(
			'id'        => 'rank-math-search-console',
			'title'     => esc_html__( 'Search Console', 'rank-math' ),
			'href'      => Helper::get_admin_url( 'search-console' ),
			'parent'    => 'rank-math',
			'meta'      => array( 'title' => esc_html__( 'Review analytics, sitemaps and crawl errors', 'rank-math' ) ),
			'_priority' => 50,
		);

		return $items;
	}

	/**
	 * CRON Job.
	 */
	public function add_day_crawler() {
		$client = new Client;
		$client->maybe_refresh_token();

		$crawler = new Data_Fetcher;
		$start   = Helper::get_midnight( time() - DAY_IN_SECONDS );
		$crawler->push_to_queue( date( 'Y-m-d', $start - ( DAY_IN_SECONDS * 1 ) ) );
		$crawler->save()->dispatch();
	}
}
