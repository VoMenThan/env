<?php
/**
 * WooCommerce general settings.
 *
 * @package    RankMath
 * @subpackage RankMath\Modules\WooCommerce
 */

?>
<h3>WooCommerce</h3>
<p>
	Nulla neque dolor, sagittis eget, iaculis quis, molestie non, velit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Nam eget dui. Nam commodo suscipit quam.
</p>
<p>
	Nulla consequat massa quis enim. Etiam sit amet orci eget eros faucibus tincidunt. Vestibulum suscipit nulla quis orci. Ut id nisl quis enim dignissim sagittis. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nunc egestas, augue at pellentesque laoreet, felis eros vehicula leo, at malesuada velit leo quis pede. Sed a libero. Aenean vulputate eleifend tellus. Nullam accumsan lorem in dui.
</p>
