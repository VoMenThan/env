<?php
/**
 * The Module Manager
 *
 * @since      0.9.0
 * @package    RankMath
 * @subpackage RankMath\Core
 * @author     MyThemeShop <admin@mythemeshop.com>
 */

namespace RankMath;

use RankMath\Traits\Hooker;

defined( 'ABSPATH' ) || exit;

/**
 * Module_Manager class.
 */
class Module_Manager {

	use Hooker;

	/**
	 * Hold modules.
	 *
	 * @var array
	 */
	public $modules = array();

	/**
	 * Hold module object.
	 *
	 * @var array
	 */
	private $controls = array();

	/**
	 * Hold active module ids.
	 *
	 * @var array
	 */
	private $active = array();

	/**
	 * The Constructor.
	 */
	public function __construct() {
		if ( Helper::is_heartbeat() ) {
			return;
		}

		$this->action( 'admin_post_save_modules', 'save' );
		$this->action( 'plugins_loaded', 'setup_modules', 1 );
		$this->action( 'plugins_loaded', 'load_modules', 2 );
	}

	/**
	 * Include default modules support.
	 */
	public function setup_modules() {
		/**
		 * Filters the array of modules available to be activated.
		 *
		 * @param array $modules Array of available modules.
		 */
		$modules = $this->do_filter( 'modules', array(
			'404-monitor'    => array(
				'id'            => '404-monitor',
				'title'         => esc_html__( '404 Monitor', 'rank-math' ),
				'desc'          => esc_html__( 'Records the URLs on which visitors & search engines run into 404 Errors. You can also turn on Redirections to redirect the error causing URLs to other URLs.', 'rank-math' ),
				'class'         => 'RankMath\Modules\Monitor\Monitor',
				'icon'          => 'dashicons-dismiss',
				'settings_link' => Helper::get_admin_url( 'options-general' ) . '#setting-panel-404-monitor',
			),

			'local-seo'      => array(
				'id'            => 'local-seo',
				'title'         => esc_html__( 'Local SEO & Google Knowledge Graph', 'rank-math' ),
				'desc'          => esc_html__( 'Dominate the search results for local audience by optimizing your website and posts using this Rank Math module.', 'rank-math' ),
				'class'         => 'RankMath\Modules\Local_Seo\Local_Seo',
				'icon'          => 'dashicons-admin-links',
				'settings_link' => Helper::get_admin_url( 'options-titles' ) . '#setting-panel-local',
			),

			'redirections'   => array(
				'id'            => 'redirections',
				'title'         => esc_html__( 'Redirections', 'rank-math' ),
				'desc'          => esc_html__( 'Redirect non-existent content easily with 301 and 302 status code. This can help reduce errors and improve your site ranking.', 'rank-math' ),
				'class'         => 'RankMath\Modules\Redirections\Redirections',
				'icon'          => 'dashicons-randomize',
				'settings_link' => Helper::get_admin_url( 'options-general' ) . '#setting-panel-redirections',
			),

			'rich-snippet'   => array(
				'id'            => 'rich-snippet',
				'title'         => esc_html__( 'Rich Snippets', 'rank-math' ),
				'desc'          => esc_html__( 'Enable support for the Rich Snippets, which adds metadata to your website, resulting in rich search results and more traffic.', 'rank-math' ),
				'class'         => 'RankMath\Modules\RichSnippet\RichSnippet',
				'icon'          => 'dashicons-awards',
				'settings_link' => Helper::get_admin_url( 'options-titles' ) . '#setting-panel-post-type-post',
			),

			'role-manager'   => array(
				'id'            => 'role-manager',
				'title'         => esc_html__( 'Role Manager', 'rank-math' ),
				'desc'          => esc_html__( 'The Role Manager allows you to use internal WordPress\' roles to control which of your site admins can change Rank Math\'s settings', 'rank-math' ),
				'class'         => 'RankMath\Modules\Role_Manager\Role_Manager',
				'icon'          => 'dashicons-admin-users',
				'only'          => 'admin',
				'settings_link' => Helper::get_admin_url( 'role-manager' ),
			),

			'search-console' => array(
				'id'            => 'search-console',
				'title'         => esc_html__( 'Search Console', 'rank-math' ),
				'desc'          => esc_html__( 'Connect Rank Math with Google Search Console to see the most important information from Google directly in your WordPress dashboard.', 'rank-math' ),
				'class'         => 'RankMath\Modules\Search_Console\Search_Console',
				'icon'          => 'dashicons-search',
				'only'          => 'admin',
				'settings_link' => Helper::get_admin_url( 'options-general' ) . '#setting-panel-search-console',
			),

			'seo-analysis'   => array(
				'id'            => 'seo-analysis',
				'title'         => esc_html__( 'SEO Analysis', 'rank-math' ),
				'desc'          => esc_html__( 'Let Rank Math analyze your website and your website\'s content using 70+ different tests to provide tailor-made SEO Analysis to you.', 'rank-math' ),
				'class'         => 'RankMath\Modules\SEO_Analysis\SEO_Analysis',
				'icon'          => 'dashicons-chart-bar',
				'only'          => 'admin',
				'settings_link' => Helper::get_admin_url( 'seo-analysis' ),
			),

			'sitemap'        => array(
				'id'            => 'sitemap',
				'title'         => esc_html__( 'Sitemap', 'rank-math' ),
				'desc'          => esc_html__( 'Enable Rank Math\'s sitemap feature, which helps search engines index your website\'s content effectively.', 'rank-math' ),
				'class'         => 'RankMath\Modules\Sitemap\Sitemap',
				'icon'          => 'dashicons-networking',
				'settings_link' => Helper::get_admin_url( 'options-sitemap' ),
			),

			'amp'            => array(
				'id'    => 'amp',
				'title' => esc_html__( 'AMP', 'rank-math' ),
				/* translators: Link to AMP plugin */
				'desc'  => sprintf( esc_html__( 'Install %s from WordPress.org to make Rank Math work with Accelerated Mobile Pages. It is required because AMP are different than WordPress pages and our plugin doesn\'t work with them out-of-the-box.', 'rank-math' ), '<a href="https://wordpress.org/plugins/amp/" target="_blank">' . esc_html__( 'AMP plugin', 'rank-math' ) . '</a>' ),
				'icon'  => 'dashicons-smartphone',
				'only'  => 'skip',
			),

			'woocommerce'    => array(
				'id'            => 'woocommerce',
				'title'         => esc_html__( 'WooCommerce', 'rank-math' ),
				'desc'          => esc_html__( 'WooCommerce module to use Rank Math to optimize WooCommerce Product Pages.', 'rank-math' ),
				'class'         => 'RankMath\Modules\WooCommerce\WooCommerce',
				'icon'          => 'dashicons-cart',
				'disabled'      => ( ! Helper::is_woocommerce_active() ),
				'disabled_text' => esc_html__( 'Please activate WooCommerce plugin to use this module.', 'rank-math' ),
			),

			'link-counter'   => array(
				'id'    => 'link-counter',
				'title' => esc_html__( 'Link Counter', 'rank-math' ),
				'desc'  => esc_html__( 'Counts the total number of internal, external links, to and fro links inside your posts.', 'rank-math' ),
				'class' => 'RankMath\Modules\Links\Links',
				'icon'  => 'dashicons-admin-links',
			),
		) );

		ksort( $modules );
		foreach ( $modules as $module ) {
			$this->add_module( $module );
		}
	}

	/**
	 * Load active modules.
	 */
	public function load_modules() {
		$this->active = get_option( 'rank_math_modules', array() );

		foreach ( $this->modules as $id => $module ) {
			if ( false === $this->can_load_module( $id, $module ) ) {
				continue;
			}

			if ( isset( $module['only'] ) && 'admin' === $module['only'] ) {
				if ( class_exists( $module['class'] . '_Common' ) ) {
					$module_common_class               = $module['class'] . '_Common';
					$this->controls[ $id . '_common' ] = new $module_common_class;
				}
				if ( ! is_admin() ) {
					continue;
				}
			}

			if ( isset( $module['class'] ) ) {
				$this->controls[ $id ] = new $module['class'];
			} else {
				$module_init_file      = isset( $module['file'] ) ? $module['file'] : rank_math()->includes_dir() . "modules/{$id}/class-rank-math-{$id}.php";
				$this->controls[ $id ] = require_once $module_init_file;
			}
		}
	}

	/**
	 * Check if we can load the module
	 *
	 * @param  string $module_id ID to get module.
	 * @param  string $module Module arguments.
	 * @return bool
	 */
	private function can_load_module( $module_id, $module ) {
		// If its an internal module should be loaded all the time.
		$is_internal = isset( $module['only'] ) && 'internal' === $module['only'];
		if ( $is_internal ) {
			return true;
		}

		$is_disabled = isset( $module['disabled'] ) && $module['disabled'];
		$can_skip    = isset( $module['only'] ) && 'skip' === $module['only'];
		$inactive    = ! in_array( $module_id, $this->active );
		if ( $is_disabled || $can_skip || $inactive ) {
			return false;
		}

		return true;
	}

	/**
	 * Display module form to enable/disable them.
	 *
	 * @codeCoverageIgnore
	 */
	public function display_form() {
		if ( ! current_user_can( 'manage_options' ) ) {
			echo 'You cant access this page.';
			return;
		}
		?>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="rank-math-ui module-listing">
			<input type="hidden" name="action" value="save_modules">
			<?php wp_nonce_field( 'rank-math-save-module', 'security' ); ?>

			<div class="two-col">
			<?php
			foreach ( $this->modules as $module_id => $module ) :
				if ( isset( $module['only'] ) && 'internal' === $module['only'] ) {
					continue;
				}

				$is_active = is_array( $this->active ) && in_array( $module_id, $this->active );
				?>
				<div class="col">
					<div class="rank-math-box">

						<span class="dashicons <?php echo isset( $module['icon'] ) ? $module['icon'] : 'dashicons-category'; ?>"></span>

						<header>
							<h3><?php echo $module['title']; ?></h3>

							<p><em><?php echo $module['desc']; ?></em></p>

							<?php if ( $is_active && ! empty( $module['settings_link'] ) ) : ?>
								<a href="<?php echo esc_url( $module['settings_link'] ); ?>" style="font-size: 17px; line-height: 1.2; display: block;"><?php esc_html_e( 'Settings', 'rank-math' ); ?></a>
							<?php endif; ?>

						</header>
						<?php
						$label_class = '';
						if ( isset( $module['disabled'] ) && $module['disabled'] ) {
							$is_active   = false;
							$label_class = 'rank-math-tooltip';
						}
						?>
						<div class="status <?php echo $is_active ? 'active' : ''; ?> wp-clearfix">
							<span class="rank-math-switch">
								<input type="checkbox" id="module-<?php echo $module_id; ?>" name="modules[]" value="<?php echo $module_id; ?>"<?php checked( $is_active ); ?> <?php disabled( ( isset( $module['disabled'] ) && $module['disabled'] ), true ); ?>>
								<label for="module-<?php echo $module_id; ?>" class="<?php echo $label_class; ?>"><?php esc_html_e( 'Toggle', 'rank-math' ); ?>
									<?php echo isset( $module['disabled_text'] ) ? '<span>' . $module['disabled_text'] . '</span>' : ''; ?>
								</label>
							</span>
							<label><?php esc_html_e( 'Status:', 'rank-math' ); ?> <span><?php echo $is_active ? esc_html__( 'Active', 'rank-math' ) : esc_html__( 'Inactive', 'rank-math' ); ?></span></label>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
			</div>

			<?php submit_button( esc_attr__( 'Save Modules', 'rank-math' ), 'primary button-xlarge', 'submit-modules', false ); ?>

		</form>
		<?php
	}

	/**
	 * Save handler.
	 *
	 * @codeCoverageIgnore
	 */
	public function save() {

		if ( ! check_admin_referer( 'rank-math-save-module', 'security' ) ) {
			die;
		}

		$modules = isset( $_POST['modules'] ) ? $_POST['modules'] : array();

		update_option( 'rank_math_modules', $modules );

		Helper::schedule_flush_rewrite();

		wp_safe_redirect( $_POST['_wp_http_referer'] );
		exit;
	}

	/**
	 * Get active modules.
	 *
	 * @codeCoverageIgnore
	 *
	 * @return array
	 */
	public function get_active_modules() {
		return $this->active;
	}

	/**
	 * Get module by id.
	 *
	 * @param  string $id ID to get module.
	 * @return object     Module class object.
	 */
	public function get_module( $id ) {
		return isset( $this->controls[ $id ] ) ? $this->controls[ $id ] : false;
	}

	/**
	 * Add module.
	 *
	 * @param array $args Module configuration.
	 */
	public function add_module( $args = array() ) {
		$this->modules[ $args['id'] ] = $args;
	}
}
