<section class="register-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <h2 class="label-content">Đăng ký thành công. Xin cảm ơn!</h2>
            </div>
        </div>
    </div>
</section>